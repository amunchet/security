# securitysystem

Custom security monitoring system, leveraging
python, websockets, and docker.