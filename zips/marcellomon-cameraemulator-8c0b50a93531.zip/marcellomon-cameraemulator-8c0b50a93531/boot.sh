#!/bin/sh
. venv/bin/activate

python cameraemulator.py
