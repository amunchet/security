#!/bin/sh

source venv/bin/activate

python displayserverfrontend.py