#  Created by Marcello Monachesi at 9/6/19, 5:30 PM

from app import app

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=9000)
