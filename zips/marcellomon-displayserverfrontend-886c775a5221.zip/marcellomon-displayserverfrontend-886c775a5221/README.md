# displayserverfrontend

Displays some, all, or one of the cameras at any given time.