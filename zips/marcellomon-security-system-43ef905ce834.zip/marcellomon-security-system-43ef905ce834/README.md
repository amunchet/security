# security-system

Security monitoring system, leveraging
python, websockets, and docker.