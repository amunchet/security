#!/bin/bash

cd ..
git clone https://marcellomon@bitbucket.org/marcellomon/cameraemulator.git
git clone https://marcellomon@bitbucket.org/marcellomon/displayserverbackend.git
git clone https://marcellomon@bitbucket.org/marcellomon/displayserverfrontend.git
git clone https://github.com/fauria/docker-vsftpd.git

